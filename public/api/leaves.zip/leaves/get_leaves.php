<?php
// public/api/leaves/get_leaves.php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

ini_set('display_errors', 0);
error_reporting(E_ALL);

// --- PERBAIKAN PATH ---
$dbPath = '../config/database.php';

if (!file_exists($dbPath)) {
    echo json_encode(["status" => false, "message" => "Config DB error"]);
    exit;
}
require_once $dbPath;

try {
    $db = (new Database())->getConnection();
    $user_id = $_GET['user_id'] ?? 0;

    // 1. Employee ID
    $stmt = $db->prepare("SELECT employee_id FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $u = $stmt->fetch(PDO::FETCH_ASSOC);
    if(!$u) { echo json_encode(["status"=>true, "data"=>[], "stats"=>[]]); exit; }
    $eid = $u['employee_id'];

    // 2. Query Union (Requests + SPPD)
    $sql = "
        SELECT 'leave' as source, id, leave_type_id as type_id, reason, start_date, end_date, status, created_at, NULL as destination 
        FROM leave_requests WHERE employee_id = :eid1
        UNION ALL
        SELECT 'sppd' as source, id, 0 as type_id, trip_purpose as reason, start_date, end_date, status, created_at, destination
        FROM business_trip_requests WHERE employee_id = :eid2
        ORDER BY created_at DESC
    ";

    $stmt = $db->prepare($sql);
    $stmt->execute([':eid1'=>$eid, ':eid2'=>$eid]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 3. Mapping Nama
    $stmtT = $db->query("SELECT id, leave_type_name FROM leave_types");
    $typesMap = $stmtT->fetchAll(PDO::FETCH_KEY_PAIR);

    $final = [];
    $stats = ['pending'=>0, 'approved'=>0, 'rejected'=>0];

    foreach($rows as $r) {
        if(isset($stats[$r['status']])) $stats[$r['status']]++;
        
        $name = "Pengajuan";
        if($r['source'] == 'leave') {
            $name = $typesMap[$r['type_id']] ?? 'Ijin';
        } else {
            $name = "SPPD " . $r['destination'];
        }
        $r['type_name'] = $name;
        $final[] = $r;
    }

    echo json_encode([
        "status" => true,
        "data" => $final,
        "stats" => $stats
    ]);

} catch (Exception $e) {
    echo json_encode(["status" => false, "message" => $e->getMessage()]);
}
?>