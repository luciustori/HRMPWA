<?php
// public/api/leaves/submit_leave.php

ini_set('display_errors', 0);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");
header("Access-Control-Allow-Methods: POST");

// --- PERBAIKAN PATH DATABASE ---
$dbPath = '../config/database.php';
if (!file_exists($dbPath)) {
    echo json_encode(["status" => false, "message" => "Config DB error"]);
    exit;
}
require_once $dbPath;

$db = (new Database())->getConnection();
$data = json_decode(file_get_contents("php://input"));

if(empty($data->user_id)) {
    echo json_encode(["status"=>false, "message"=>"User ID required"]);
    exit;
}

try {
    // 1. Get Employee ID
    $stmt = $db->prepare("SELECT employee_id FROM users WHERE id = ?");
    $stmt->execute([$data->user_id]);
    $u = $stmt->fetch(PDO::FETCH_ASSOC);
    if(!$u) throw new Exception("User ID invalid");
    $eid = $u['employee_id'];

    // 2. Upload File (Base64)
    $docPath = null;
    if (!empty($data->attachment)) {
        $parts = explode(";base64,", $data->attachment);
        $image_base64 = base64_decode($parts[1] ?? $data->attachment);
        $file = 'doc_' . time() . '.jpg';
        
        // --- PERBAIKAN PATH UPLOAD ---
        // Dari: public/api/leaves/
        // Ke: public/uploads/docs/
        // Mundur 2 langkah: ../../uploads/docs/
        $uploadDir = __DIR__ . '/../../uploads/docs/'; 
        
        if(!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
        file_put_contents($uploadDir . $file, $image_base64);
        $docPath = $file;
    }

    // 3. Insert Logic
    $days = (new DateTime($data->start_date))->diff(new DateTime($data->end_date))->days + 1;

    if ($data->category === 'sppd') {
        $sql = "INSERT INTO business_trip_requests (employee_id, trip_purpose, destination, start_date, end_date, total_days, estimated_budget, supporting_document, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', NOW())";
        $db->prepare($sql)->execute([$eid, $data->reason, $data->destination, $data->start_date, $data->end_date, $days, $data->budget, $docPath]);
    } else {
        $ltid = ($data->category == 'cuti') ? $data->annual_id : (($data->category == 'dinas_luar') ? $data->dl_id : $data->leave_type_id);
        $sql = "INSERT INTO leave_requests (employee_id, leave_type_id, request_date, start_date, end_date, total_days, reason, supporting_document, status, created_at) VALUES (?, ?, CURDATE(), ?, ?, ?, ?, ?, 'pending', NOW())";
        $db->prepare($sql)->execute([$eid, $ltid, $data->start_date, $data->end_date, $days, $data->reason, $docPath]);
    }

    echo json_encode(["status" => true, "message" => "Berhasil dikirim!"]);

} catch (Exception $e) {
    echo json_encode(["status" => false, "message" => $e->getMessage()]);
}
?>