<?php
// public/api/leaves/get_form_data.php

// Matikan error HTML agar response bersih
ini_set('display_errors', 0);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

// --- PERBAIKAN PATH (SESUAI DASHBOARD_DATA.PHP) ---
$dbPath = '../config/database.php';

if (!file_exists($dbPath)) {
    // Fallback error handling
    echo json_encode(["status" => false, "message" => "Config not found at: $dbPath"]);
    exit;
}

require_once $dbPath;

try {
    $db = (new Database())->getConnection();
    $user_id = $_GET['user_id'] ?? 0;

    // 1. Cari Employee ID
    $stmtUser = $db->prepare("SELECT employee_id FROM users WHERE id = ?");
    $stmtUser->execute([$user_id]);
    $user = $stmtUser->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) { 
        echo json_encode(["status" => false, "message" => "User invalid"]); 
        exit; 
    }
    $eid = $user['employee_id'];

    // 2. Ambil Sisa Cuti
    $quota = 0;
    try {
        $stmtQ = $db->prepare("SELECT annual_leave_balance FROM employees WHERE id = ?");
        $stmtQ->execute([$eid]);
        $res = $stmtQ->fetch(PDO::FETCH_ASSOC);
        $quota = $res ? $res['annual_leave_balance'] : 0;
    } catch(Exception $ex) { $quota = 0; }

    // 3. Ambil Tipe Ijin (Exclude Cuti & Dinas)
    $sqlTypes = "SELECT id, leave_type_name FROM leave_types 
                 WHERE is_active = 1 
                 AND leave_code NOT IN ('ANNUAL','CUTI_TAHUNAN','DL','DINAS_LUAR')
                 AND leave_type_name NOT LIKE '%Tahunan%'
                 ORDER BY leave_type_name ASC";
    
    $stmtTypes = $db->query($sqlTypes);
    $types = $stmtTypes->fetchAll(PDO::FETCH_ASSOC);

    // 4. ID Spesial (Annual & DL)
    $stmtAnn = $db->query("SELECT id FROM leave_types WHERE leave_code IN ('ANNUAL','CUTI_TAHUNAN') LIMIT 1");
    $ann = $stmtAnn->fetch(PDO::FETCH_ASSOC);

    $stmtDl = $db->query("SELECT id FROM leave_types WHERE leave_code IN ('DL','DINAS_LUAR') LIMIT 1");
    $dl = $stmtDl->fetch(PDO::FETCH_ASSOC);

    echo json_encode([
        "status" => true,
        "data" => [
            "quota" => $quota,
            "permit_types" => $types,
            "special_ids" => [
                "annual" => $ann ? $ann['id'] : 0,
                "dl" => $dl ? $dl['id'] : 0
            ]
        ]
    ]);

} catch (Exception $e) {
    echo json_encode(["status" => false, "message" => $e->getMessage()]);
}
?>