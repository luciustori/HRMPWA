<div class="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
    <div>
        <h1 class="text-2xl font-bold text-gray-800">Master Shift Kerja</h1>
        <p class="text-sm text-gray-500">Daftar jam kerja yang berlaku.</p>
    </div>
    <div class="flex gap-2">
        <a href="<?= BASEURL ?>/admin/schedules/calendar" class="bg-white border text-gray-700 px-4 py-2 rounded-lg text-sm font-medium shadow-sm hover:bg-gray-50">
            <i class="far fa-calendar-alt mr-2"></i> Kalender
        </a>
        <a href="<?= BASEURL ?>/admin/schedules/shifts_create" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-medium shadow-md transition flex items-center">
            <i class="fas fa-plus mr-2"></i> Tambah Shift
        </a>
    </div>
</div>

<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
    <table class="w-full text-sm text-left">
        <thead class="bg-gray-50 text-gray-700 font-bold border-b border-gray-100">
            <tr>
                <th class="px-6 py-4">Kode</th>
                <th class="px-6 py-4">Nama Shift</th>
                <th class="px-6 py-4">Jam Kerja</th>
                <th class="px-6 py-4">Total Jam</th>
                <th class="px-6 py-4">Status</th>
                <th class="px-6 py-4 text-center">Aksi</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
            <?php foreach($shifts as $s): ?>
            <tr class="hover:bg-gray-50">
                <td class="px-6 py-4"><span class="bg-indigo-50 text-indigo-700 px-2 py-1 rounded text-xs font-bold"><?= $s['shift_code'] ?></span></td>
                <td class="px-6 py-4 font-bold text-gray-700"><?= $s['shift_name'] ?></td>
                <td class="px-6 py-4"><?= date('H:i', strtotime($s['start_time'])) ?> - <?= date('H:i', strtotime($s['end_time'])) ?></td>
                <td class="px-6 py-4"><?= $s['total_hours'] ?> Jam</td>
                <td class="px-6 py-4">
                    <?= $s['is_active'] ? '<span class="text-green-600 text-xs font-bold">Aktif</span>' : '<span class="text-red-600 text-xs font-bold">Nonaktif</span>' ?>
                </td>
                <td class="px-6 py-4 text-center">
                    <a href="<?= BASEURL ?>/admin/schedules/shifts_edit/<?= $s['id'] ?>" class="text-yellow-600 hover:text-yellow-800 mx-1"><i class="fas fa-pen"></i></a>
                    <a href="<?= BASEURL ?>/admin/schedules/shifts_delete/<?= $s['id'] ?>" onclick="return confirm('Hapus?')" class="text-red-600 hover:text-red-800 mx-1"><i class="fas fa-trash"></i></a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>