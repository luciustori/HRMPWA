<div class="max-w-2xl mx-auto bg-white rounded-xl shadow-sm border border-gray-100 p-6">
    <h2 class="text-xl font-bold text-gray-800 mb-6">Tambah Hari Libur</h2>
    <form action="<?= BASEURL ?>/admin/schedules/holidays_store" method="POST" class="space-y-6">
        <div>
            <label class="block text-sm font-bold text-gray-700 mb-2">Tanggal Libur</label>
            <input type="date" name="holiday_date" required class="w-full rounded-lg border-gray-300 focus:ring-indigo-500">
        </div>
        <div>
            <label class="block text-sm font-bold text-gray-700 mb-2">Nama Hari Libur</label>
            <input type="text" name="holiday_name" required placeholder="Contoh: Tahun Baru Imlek" class="w-full rounded-lg border-gray-300 focus:ring-indigo-500">
        </div>
        <div>
            <label class="block text-sm font-bold text-gray-700 mb-2">Jenis Libur</label>
            <select name="holiday_type" class="w-full rounded-lg border-gray-300">
                <option value="national">Libur Nasional (Merah)</option>
                <option value="company">Cuti Bersama (Potong Cuti)</option>
                <option value="religious">Hari Raya Keagamaan</option>
            </select>
        </div>
        <div>
            <label class="block text-sm font-bold text-gray-700 mb-2">Deskripsi</label>
            <textarea name="description" rows="2" class="w-full rounded-lg border-gray-300"></textarea>
        </div>
        <div class="pt-4 flex justify-end gap-2">
            <a href="<?= BASEURL ?>/admin/schedules/holidays" class="px-4 py-2 text-gray-600 border rounded-lg">Batal</a>
            <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-indigo-700">Simpan</button>
        </div>
    </form>
</div>