<div class="max-w-4xl mx-auto bg-white rounded-xl shadow-sm border border-gray-100 p-6">
    <h2 class="text-xl font-bold text-gray-800 mb-6">Tambah Shift Baru</h2>
    <form action="<?= BASEURL ?>/admin/schedules/shifts_store" method="POST" class="space-y-6">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label class="block text-sm font-bold text-gray-700 mb-2">Nama Shift</label>
                <input type="text" name="shift_name" required class="w-full rounded-lg border-gray-300 focus:ring-indigo-500">
            </div>
            <div>
                <label class="block text-sm font-bold text-gray-700 mb-2">Kode Shift</label>
                <input type="text" name="shift_code" required placeholder="PAGI/SIANG" class="w-full rounded-lg border-gray-300 focus:ring-indigo-500 uppercase">
            </div>
            <div>
                <label class="block text-sm font-bold text-gray-700 mb-2">Jam Masuk</label>
                <input type="time" name="start_time" required class="w-full rounded-lg border-gray-300">
            </div>
            <div>
                <label class="block text-sm font-bold text-gray-700 mb-2">Jam Pulang</label>
                <input type="time" name="end_time" required class="w-full rounded-lg border-gray-300">
            </div>
            <div>
                <label class="block text-sm font-bold text-gray-700 mb-2">Toleransi Telat (Menit)</label>
                <input type="number" name="late_tolerance_minutes" value="15" class="w-full rounded-lg border-gray-300">
            </div>
            <div class="flex items-center pt-6">
                <input type="checkbox" name="is_active" checked class="rounded text-indigo-600 focus:ring-indigo-500 mr-2">
                <span class="text-sm font-bold text-gray-700">Status Aktif</span>
            </div>
        </div>
        <div class="pt-4 flex justify-end">
            <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded-lg font-bold hover:bg-indigo-700">Simpan</button>
        </div>
    </form>
</div>