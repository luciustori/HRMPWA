<div class="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
    <div>
        <h1 class="text-2xl font-bold text-gray-800">Hari Libur & Cuti Bersama</h1>
        <p class="text-sm text-gray-500">Manajemen tanggal merah tahun <?= $year ?>.</p>
    </div>
    <div class="flex gap-2">
        <form method="GET" class="flex gap-2">
            <select name="year" onchange="this.form.submit()" class="border-gray-300 rounded-lg text-sm py-2 focus:ring-indigo-500 focus:border-indigo-500">
                <?php for($y=date('Y')-1; $y<=date('Y')+1; $y++): ?>
                    <option value="<?= $y ?>" <?= $year==$y ? 'selected':'' ?>><?= $y ?></option>
                <?php endfor; ?>
            </select>
        </form>
        <a href="<?= BASEURL ?>/admin/schedules/holidays_create" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm font-medium shadow-md flex items-center">
            <i class="fas fa-plus mr-2"></i> Tambah Libur
        </a>
    </div>
</div>

<div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
    <table class="w-full text-sm text-left">
        <thead class="bg-gray-50 text-gray-700 font-bold border-b border-gray-100">
            <tr>
                <th class="px-6 py-4">Tanggal</th>
                <th class="px-6 py-4">Keterangan</th>
                <th class="px-6 py-4">Jenis</th>
                <th class="px-6 py-4 text-center">Aksi</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
            <?php if(!empty($holidays)): ?>
                <?php foreach($holidays as $h): ?>
                <tr class="hover:bg-gray-50">
                    <td class="px-6 py-4 font-mono font-bold text-indigo-600"><?= date('d M Y', strtotime($h['holiday_date'])) ?></td>
                    <td class="px-6 py-4 font-bold text-gray-700">
                        <?= $h['holiday_name'] ?>
                        <div class="text-xs text-gray-400 font-normal"><?= $h['description'] ?></div>
                    </td>
                    <td class="px-6 py-4">
                        <span class="px-2 py-1 rounded text-xs font-bold 
                            <?= $h['holiday_type']=='national' ? 'bg-red-100 text-red-600' : 'bg-yellow-100 text-yellow-600' ?>">
                            <?= ucfirst($h['holiday_type']) ?>
                        </span>
                    </td>
                    <td class="px-6 py-4 text-center">
                        <a href="<?= BASEURL ?>/admin/schedules/holidays_edit/<?= $h['id'] ?>" class="text-yellow-600 hover:text-yellow-800 mx-1"><i class="fas fa-pen"></i></a>
                        <a href="<?= BASEURL ?>/admin/schedules/holidays_delete/<?= $h['id'] ?>" onclick="return confirm('Hapus?')" class="text-red-600 hover:text-red-800 mx-1"><i class="fas fa-trash"></i></a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr><td colspan="4" class="p-8 text-center text-gray-500">Tidak ada hari libur tahun ini.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>