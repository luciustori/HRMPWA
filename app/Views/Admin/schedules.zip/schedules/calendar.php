<style>
    .sticky-col { position: sticky; left: 0; background: white; z-index: 10; border-right: 2px solid #e2e8f0; }
    .sticky-header { position: sticky; top: 0; z-index: 20; background: #f8fafc; }
    .custom-checkbox { width: 18px; height: 18px; cursor: pointer; }
</style>

<div class="flex flex-col h-full" x-data="calendarApp()">
    
    <div class="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
        <div>
            <h1 class="text-2xl font-bold text-gray-800">Kalender Shift</h1>
            <p class="text-sm text-gray-500">Atur jadwal kerja bulanan.</p>
        </div>
        
        <div class="flex items-center bg-white border border-gray-200 rounded-lg shadow-sm p-1">
            <?php 
                $prev = date('Y-m', strtotime("$year-$month-01 -1 month"));
                $next = date('Y-m', strtotime("$year-$month-01 +1 month"));
            ?>
            <a href="?month=<?= $prev ?>" class="px-3 py-1 text-gray-600 hover:bg-gray-100 rounded-md"><i class="fas fa-chevron-left"></i></a>
            <span class="px-4 font-bold text-gray-700 min-w-[150px] text-center">
                <?= date('F Y', strtotime("$year-$month-01")) ?>
            </span>
            <a href="?month=<?= $next ?>" class="px-3 py-1 text-gray-600 hover:bg-gray-100 rounded-md"><i class="fas fa-chevron-right"></i></a>
        </div>
    </div>

    <div class="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden flex-1 relative">
        <div class="overflow-auto max-h-[70vh]">
            <table class="w-full text-sm border-collapse">
                <thead class="sticky-header shadow-sm">
                    <tr>
                        <th class="p-3 text-left sticky-col min-w-[250px] bg-gray-50 border-b border-gray-200">
                            <div class="flex items-center gap-3">
                                <input type="checkbox" @change="toggleAll($event)" class="custom-checkbox rounded text-indigo-600">
                                <span>Karyawan</span>
                            </div>
                        </th>
                        <?php 
                            $daysInMonth = date('t', strtotime("$year-$month-01"));
                            for ($d = 1; $d <= $daysInMonth; $d++):
                                $date = sprintf('%04d-%02d-%02d', $year, $month, $d);
                                $dayName = date('D', strtotime($date));
                                $isWeekend = in_array($dayName, ['Sat', 'Sun']);
                                $color = $isWeekend ? 'text-red-500 bg-red-50' : 'text-gray-600';
                        ?>
                        <th class="p-2 text-center border-l border-b border-gray-200 min-w-[60px] <?= $color ?>">
                            <div class="text-xs font-bold"><?= $d ?></div>
                            <div class="text-[10px] uppercase"><?= $dayName ?></div>
                        </th>
                        <?php endfor; ?>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-100">
                    <?php foreach ($employees as $emp): ?>
                    <tr class="hover:bg-gray-50 transition-colors">
                        
                        <td class="p-3 sticky-col bg-white group border-b border-gray-100">
                            <div class="flex items-center gap-3">
                                <input type="checkbox" value="<?= $emp['id'] ?>" x-model="selectedEmployees" class="custom-checkbox rounded text-indigo-600">
                                <div>
                                    <div class="font-bold text-gray-800 text-xs md:text-sm">
                                        <?= $emp['first_name'] . ' ' . $emp['last_name'] ?>
                                    </div>
                                    <div class="text-[10px] text-gray-400"><?= $emp['department_name'] ?></div>
                                </div>
                            </div>
                        </td>

                        <?php 
                            for ($d = 1; $d <= $daysInMonth; $d++):
                                $date = sprintf('%04d-%02d-%02d', $year, $month, $d);
                                $key = $date . '_' . $emp['id'];
                                $hasShift = isset($assignment_map[$key]);
                                $shift = $hasShift ? $assignment_map[$key] : null;
                                $isMod = $hasShift && $shift['is_mod'];
                        ?>
                        <td class="border-l border-b border-gray-100 p-1 text-center cursor-pointer hover:bg-indigo-50 transition relative"
                            @click="openSingleModal(<?= $emp['id'] ?>, '<?= $date ?>', '<?= $shift['shift_id'] ?? '' ?>', <?= $isMod ? 'true' : 'false' ?>)">
                            
                            <?php if ($hasShift): ?>
                                <div class="w-full h-8 flex items-center justify-center rounded text-[10px] font-bold shadow-sm relative transition-all hover:scale-105
                                            <?= $isMod ? 'border-2 border-yellow-400' : '' ?>"
                                     style="background-color: #dbeafe; color: #1e40af;">
                                    <?= $shift['shift_code'] ?>
                                    <?php if($isMod): ?>
                                        <span class="absolute -top-1.5 -right-1.5 text-[8px]">⭐</span>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="w-full h-8 flex items-center justify-center text-gray-200 text-xs hover:text-gray-400">
                                    +
                                </div>
                            <?php endif; ?>

                        </td>
                        <?php endfor; ?>

                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div x-show="selectedEmployees.length > 0" 
         x-transition:enter="transition ease-out duration-300"
         x-transition:enter-start="transform translate-y-full opacity-0"
         x-transition:enter-end="transform translate-y-0 opacity-100"
         class="fixed bottom-0 left-0 right-0 md:ml-64 bg-white border-t border-indigo-100 shadow-[0_-4px_6px_-1px_rgba(0,0,0,0.1)] p-4 z-40">
        
        <form @submit.prevent="submitBulk" class="flex flex-col md:flex-row items-center gap-4 max-w-7xl mx-auto">
            
            <div class="flex items-center gap-2 text-indigo-800 font-bold bg-indigo-50 px-3 py-1 rounded-lg text-sm">
                <span x-text="selectedEmployees.length"></span> <span>Terpilih</span>
                <button type="button" @click="selectedEmployees = []" class="ml-2 text-xs text-red-500 hover:underline">Batal</button>
            </div>

            <div class="flex items-center gap-2">
                <input type="date" x-model="bulk.start" class="text-sm border-gray-300 rounded-lg focus:ring-indigo-500" required>
                <span class="text-gray-400">-</span>
                <input type="date" x-model="bulk.end" class="text-sm border-gray-300 rounded-lg focus:ring-indigo-500" required>
            </div>

            <div class="hidden md:flex gap-1">
                <template x-for="day in days">
                    <label class="cursor-pointer select-none">
                        <input type="checkbox" :value="day.val" x-model="bulk.days" class="hidden peer">
                        <span class="px-2 py-1 text-xs border rounded bg-gray-50 text-gray-500 peer-checked:bg-indigo-600 peer-checked:text-white transition" x-text="day.label"></span>
                    </label>
                </template>
            </div>

            <select x-model="bulk.shift_id" class="text-sm border-gray-300 rounded-lg focus:ring-indigo-500 min-w-[150px]" required>
                <option value="">-- Pilih Shift --</option>
                <?php foreach($shifts as $s): ?>
                    <option value="<?= $s['id'] ?>"><?= $s['shift_name'] ?> (<?= substr($s['start_time'],0,5) ?>)</option>
                <?php endforeach; ?>
            </select>

            <label class="flex items-center gap-2 text-sm text-gray-700 cursor-pointer select-none">
                <input type="checkbox" x-model="bulk.is_mod" class="rounded text-indigo-600 focus:ring-indigo-500">
                <span class="font-bold text-orange-600">MOD?</span>
            </label>

            <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg font-bold text-sm shadow-md transition ml-auto flex items-center gap-2">
                <i class="fas fa-check-double"></i> Terapkan
            </button>

        </form>
    </div>

    <div x-show="modalOpen" class="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" style="display: none;">
        <div class="bg-white rounded-xl shadow-xl max-w-sm w-full p-6 transform transition-all" @click.away="modalOpen = false">
            <h3 class="font-bold text-lg text-gray-800 mb-4">Edit Jadwal Harian</h3>
            <form @submit.prevent="submitSingle">
                <div class="mb-4">
                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Tanggal</label>
                    <input type="date" x-model="single.date" class="w-full border-gray-200 rounded-lg bg-gray-50 text-gray-500 cursor-not-allowed" readonly>
                </div>
                <div class="mb-4">
                    <label class="block text-xs font-bold text-gray-500 uppercase mb-1">Shift</label>
                    <select x-model="single.shift_id" class="w-full border-gray-300 rounded-lg focus:ring-indigo-500">
                        <option value="">-- Libur / Kosong --</option>
                        <?php foreach($shifts as $s): ?>
                            <option value="<?= $s['id'] ?>"><?= $s['shift_name'] ?> (<?= substr($s['start_time'],0,5) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-6">
                    <label class="flex items-center gap-2 cursor-pointer bg-orange-50 p-3 rounded-lg border border-orange-100">
                        <input type="checkbox" x-model="single.is_mod" class="rounded text-orange-600 focus:ring-orange-500">
                        <div>
                            <span class="text-sm font-bold text-gray-700 block">Manager on Duty</span>
                            <span class="text-xs text-gray-500">Tambahan Insentif Rp 100.000</span>
                        </div>
                    </label>
                </div>
                <div class="flex justify-end gap-2">
                    <button type="button" @click="modalOpen = false" class="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg">Batal</button>
                    <button type="submit" class="px-4 py-2 bg-indigo-600 text-white font-bold rounded-lg hover:bg-indigo-700">Simpan</button>
                </div>
            </form>
        </div>
    </div>

</div>

<script>
function calendarApp() {
    return {
        selectedEmployees: [],
        modalOpen: false,
        
        // Data Single Edit
        single: { employee_id: null, date: null, shift_id: '', is_mod: false },
        
        // Data Bulk Edit
        bulk: { 
            start: '<?= "$year-$month-01" ?>', 
            end: '<?= date("Y-m-t", strtotime("$year-$month-01")) ?>', 
            shift_id: '', 
            days: [1,2,3,4,5], // Default Sen-Jum
            is_mod: false 
        },
        
        days: [
            {val: 1, label: 'Sen'}, {val: 2, label: 'Sel'}, {val: 3, label: 'Rab'},
            {val: 4, label: 'Kam'}, {val: 5, label: 'Jum'}, {val: 6, label: 'Sab'}, {val: 7, label: 'Min'}
        ],

        toggleAll(e) {
            if (e.target.checked) {
                this.selectedEmployees = Array.from(document.querySelectorAll('input[type="checkbox"][value]'))
                                              .map(el => el.value)
                                              .filter(val => val);
            } else {
                this.selectedEmployees = [];
            }
        },

        openSingleModal(empId, date, shiftId, isMod) {
            this.single = {
                employee_id: empId,
                date: date,
                shift_id: shiftId,
                is_mod: isMod
            };
            this.modalOpen = true;
        },

        submitSingle() {
            let formData = new FormData();
            formData.append('employee_id', this.single.employee_id);
            formData.append('assignment_date', this.single.date);
            formData.append('shift_id', this.single.shift_id);
            if(this.single.is_mod) formData.append('is_mod', 1);

            fetch('<?= BASEURL ?>/admin/schedules/assign', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                if(data.success) location.reload();
            });
        },

        submitBulk() {
            if(!confirm('Terapkan jadwal massal untuk ' + this.selectedEmployees.length + ' karyawan?')) return;

            let formData = new FormData();
            this.selectedEmployees.forEach(id => formData.append('employee_ids[]', id));
            this.bulk.days.forEach(d => formData.append('days[]', d));
            
            formData.append('start_date', this.bulk.start);
            formData.append('end_date', this.bulk.end);
            formData.append('shift_id', this.bulk.shift_id);
            if(this.bulk.is_mod) formData.append('is_mod', 1);

            fetch('<?= BASEURL ?>/admin/schedules/bulk_assign', { method: 'POST', body: formData })
            .then(res => res.json())
            .then(data => {
                alert(data.message);
                if(data.success) location.reload();
            });
        }
    }
}
</script>